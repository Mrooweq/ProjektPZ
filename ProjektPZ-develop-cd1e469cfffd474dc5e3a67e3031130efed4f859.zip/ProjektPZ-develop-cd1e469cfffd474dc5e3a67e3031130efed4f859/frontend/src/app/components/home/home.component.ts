import {Component} from '@angular/core';

@Component({
  selector: 'home',
  template: 'home'
})
export class Home{
}
