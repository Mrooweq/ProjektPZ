## JAK ŻYĆ ?
### Wymagania:
- git
- maven
- node.js

### Eclipse:
Aby importować projekt do eclipsa `File > Import > Maven > Existing maven projects ` i wybrać lokalizacje backendu.

### Backend:
Aby uruchomić backend należy:
```
cd backend
mvn spring-boot:run
```

### Frontend:
Aby uruchomić frontend należy:
```
cd frontend
npm install //tylko za pierwszym razem
npm start
```